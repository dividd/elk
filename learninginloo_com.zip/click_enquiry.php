<?php 
require_once 'Mandrill_Api/src/Mandrill.php';
$mandrill = new Mandrill('bJ0APu1q1CMbGD2ysPBrmg');
		
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
	$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$ip = $_SERVER['REMOTE_ADDR'];
}

$info=$_POST;
if (!empty($_POST)) 
{
	foreach($_POST as $index => $val){
		if($val!=''){
			$info[$index] = $val;	
		}
	}
}

if($_POST['email']!="") 
{
	$email_details['UserName'] = $info['name'];
	$info['IP_Address']= $_SERVER['REMOTE_ADDR'];
	$info['Referer_Page']= $_SERVER['HTTP_REFERER'];

	$Subject = "Learninginloo | Click Enquiry";

	$body = "Dear Admin, <br/><br/> \n User Details as follows:<br/><br/>";
	$body.='<strong>Name: </strong>'. $_POST['name'].'<br/>';
	if($_POST['email']!="")
	{
	$body.='<strong>Email: </strong>'. $_POST['email'].'<br/>';}
	if($_POST['phone']!="")
	{
	    $body .= "<strong>Phone: </strong>".$_POST['phone']."<br/>";
	}
	$body.='<strong>Ip Address: </strong>'.$ip.'<br/>';
	$body.='<strong>Refferal Link: </strong>'.$_SERVER["HTTP_REFERER"].'<br/>';
	$body .="<br>Thanks & Regards,<br> learninginloo.com";
	
	$message = array(
		'html' => $body,
		'subject' => $Subject,
		'from_email' => 'info@learninginloo.com',
		'from_name' => 'learninginloo.com',
		'to' => array(
			array(
			'email' => "pnt.chd@gmail.com",  // web@thesisindia.net, 
			'name' => "Admin",
			'type' => 'to'
			)
		)
	);
	$async = false;
	$ip_pool = '';

	$result = $mandrill->messages->send($message, $async, $ip_pool);
	if($result) 
	{
		echo "Success";
	}
	else 
	{
		echo $mail->ErrorInfo;
		echo "fail";	
	}
}
else 
{
	echo "Invalid Email";	
}
?>