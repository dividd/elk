
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8" />
        <title>Learninginloo.com</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="author" content="" />
        <meta name="Version" content="v3.2.0" />
        <!-- favicon -->
        <link rel="shortcut icon" href="images/favicon.ico">
        <!-- Bootstrap -->
        <link href="css/bootstrap.min.css" rel="preload" as="style" type="text/css" media="screen" onload="this.onload=null;this.rel='stylesheet'">
        <link href="css/style.min.css" rel="preload" as="style" type="text/css" id="theme-opt" media="screen" onload="this.onload=null;this.rel='stylesheet'">
        <link href="css/colors/default.css" rel="preload" as="style" id="color-opt" media="screen" onload="this.onload=null;this.rel='stylesheet'">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" media="screen">
		
		<link href="https://fonts.googleapis.com/css?family=Nunito:300,400,600,700&display=swap" rel="preload" as="style" media="screen" onload="this.onload=null;this.rel='stylesheet'">
			<link href="https://fonts.googleapis.com/css2?family=Livvic:wght@400;500;600;700&display=swap"rel="preload" as="style" media="screen" onload="this.onload=null;this.rel='stylesheet'">
	

        <style>
            .error{
                color:red;
            }
        </style>

    </head>

    <body>
       
        <!-- Navbar STart -->
        <header id="topnav" class="defaultscroll sticky">
            <div class="container">
                <!-- Logo container-->
                <a class="logo" href="index.html">
                    <span class="logo-light-mode">
                        <img src="images/learning.png" class="l-dark" alt="">
                        <img src="images/learning.png" class="l-light" alt="">
                    </span>
                    <img src="images/learning.png"  class="logo-dark-mode img-fluid" alt="">
                </a>
                <div class="buy-button">
                    <p><i class="fa fa-envelope" aria-hidden="true"></i> Email: <a href="mailto:info@learninginloo.com">info@learninginloo.com</a></p>
                </div><!--end login button-->
               
     
            </div><!--end container-->
        </header><!--end header-->
      
        <section class="bg-half-260 pb-lg-0 pb-md-4d-table w-100">
            <div class="bg-overlay" style="opacity: 0.8;"></div>
            <div class="container">
                <div class="row position-relative" style="z-index: 1;">
                    <div class="col-md-7 col-12 mt-lg-5">
                        <div class="title-heading">
                            <h1 class="heading title-dark mb-4">Taking the e-Learning Experience

  <br>To the Next Level with Us</h1>
                            <p class="para-desc text-dark-50">With a lot of e-Learning courses and subjects, it has not become any easier to learn but more confusing as to give longer hours in understanding and learning new things. However, Learninginloo has brought shorter, easier modules to provide you with a whole new online learning experience.</p>
                        </div>
                        
                    </div><!--end col-->

                    <div class="col-md-5 col-12 mt-4 pt-2 mt-sm-0 pt-sm-0 mt-5">
                        <div id="msgloader1"></div>
						<div class="card shadow rounded border-0 me-lg-3 mt-4">
						    
                            <div class="card-body p-3">
                                <h5 class="card-title">Contact Our Team For Assistance</h5>

                                <form class="login-form" method="post" id="contactus" name="contactus" onsubmit="return validateform();">
                                     <input type="hidden" name="start_time1" id="start_time1" value="<?php echo time();?>">
                <input type="hidden" name="checkval1" id="checkval1" value="">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Name <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    <input type="text" class="form-control pl-2" placeholder="Enter Name" name="fname" id="fname" onKeyPress="return ValidateAlpha(event);">
                                            <span id="fnameErr" class="error"></span>        
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Email ID <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                   <input type="email" class="form-control pl-2" placeholder="Enter Email Id" name="emailid" id="emailid">
                                        <span id="emailidErr" class="error"></span>
                                                </div>
                                            </div>
                                        </div>
                                       <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Country <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                   <select name="countryname" id="countryname" class="form-control pl-2" onChange="getcountrycode1(this)">

                    <option value="">Select Country</option>

                    <option value="Algeria " id="213">Algeria </option>

                    <option value="Andorra " id="376">Andorra </option>

                    <option value="Angola " id="244">Angola </option>

                    <option value="Anguilla " id="1264">Anguilla </option>

                    <option value="Antigua &amp; Barbuda " id="1268">Antigua &amp; Barbuda </option>

                    <option value="Antilles Dutch" id="599">Antilles Dutch</option>

                    <option value="Argentina " id="54">Argentina </option>

                    <option value="Armenia " id="374">Armenia </option>

                    <option value="Aruba " id="297">Aruba </option>

                    <option value="Ascension Island " id="247">Ascension Island </option>

                    <option value="Australia " id="61">Australia </option>

                    <option value="Austria " id="43">Austria </option>

                    <option value="Azerbaijan " id="994">Azerbaijan </option>

                    <option value="Bahamas " id="1242">Bahamas </option>

                    <option value="Bahrain " id="973">Bahrain </option>

                    <option value="Bangladesh " id="880">Bangladesh </option>

                    <option value="Barbados " id="1246">Barbados </option>

                    <option value="Belarus " id="375">Belarus </option>

                    <option value="Belgium " id="32">Belgium </option>

                    <option value="Belize " id="501">Belize </option>

                    <option value="Benin " id="229">Benin </option>

                    <option value="Bermuda " id="1441">Bermuda </option>

                    <option value="Bhutan " id="975">Bhutan </option>

                    <option value="Bolivia " id="591">Bolivia </option>

                    <option value="Bosnia Herzegovina " id="387">Bosnia Herzegovina </option>

                    <option value="Botswana " id="267">Botswana </option>

                    <option value="Brazil " id="55">Brazil </option>

                    <option value="Brunei " id="673">Brunei </option>

                    <option value="Bulgaria " id="359">Bulgaria </option>

                    <option value="Burkina Faso " id="226">Burkina Faso </option>

                    <option value="Burundi " id="257">Burundi </option>

                    <option value="Cambodia " id="855">Cambodia </option>

                    <option value="Cameroon " id="237">Cameroon </option>

                    <option value="Canada " id="1">Canada </option>

                    <option value="Cape Verde Islands " id="238">Cape Verde Islands </option>

                    <option value="Cayman Islands " id="1345">Cayman Islands </option>

                    <option value="Central African Republic " id="236">Central African Republic </option>

                    <option value="Chile " id="56">Chile </option>

                    <option value="China " id="87">China </option>

                    <option value="Colombia " id="57">Colombia </option>

                    <option value="Comoros " id="270">Comoros </option>

                    <option value="Congo " id="242">Congo </option>

                    <option value="Cook Islands " id="682">Cook Islands </option>

                    <option value="Costa Rica " id="506">Costa Rica </option>

                    <option value="Croatia " id="385">Croatia </option>

                    <option value="Cuba " id="53">Cuba </option>

                    <option value="Cyprus North " id="90392">Cyprus North </option>

                    <option value="Cyprus South " id="357">Cyprus South </option>

                    <option value="Czech Republic " id="42">Czech Republic </option>

                    <option value="Denmark " id="45">Denmark </option>

                    <option value="Diego Garcia " id="2463">Diego Garcia </option>

                    <option value="Djibouti " id="253">Djibouti </option>

                    <option value="Dominica " id="1809">Dominica </option>

                    <option value="Dominican Republic " id="1810">Dominican Republic </option>

                    <option value="Ecuador " id="593">Ecuador </option>

                    <option value="Egypt " id="20">Egypt </option>

                    <option value="Eire " id="353">Eire </option>

                    <option value="El Salvador " id="503">El Salvador </option>

                    <option value="Equatorial Guinea " id="240">Equatorial Guinea </option>

                    <option value="Eritrea " id="291">Eritrea </option>

                    <option value="Estonia " id="372">Estonia </option>

                    <option value="Ethiopia " id="251">Ethiopia </option>

                    <option value="Falkland Islands " id="500">Falkland Islands </option>

                    <option value="Faroe Islands " id="298">Faroe Islands </option>

                    <option value="Fiji " id="679">Fiji </option>

                    <option value="Finland " id="358">Finland </option>

                    <option value="France " id="33">France </option>

                    <option value="French Guiana " id="594">French Guiana </option>

                    <option value="French Polynesia " id="689">French Polynesia </option>

                    <option value="Gabon " id="241">Gabon </option>

                    <option value="Gambia " id="220">Gambia </option>

                    <option value="Georgia " id="7880">Georgia </option>

                    <option value="Germany " id="49">Germany </option>

                    <option value="Ghana " id="233">Ghana </option>

                    <option value="Gibraltar " id="350">Gibraltar </option>

                    <option value="Greece " id="30">Greece </option>

                    <option value="Greenland " id="299">Greenland </option>

                    <option value="Grenada " id="1473">Grenada </option>

                    <option value="Guadeloupe " id="590">Guadeloupe </option>

                    <option value="Guam " id="671">Guam </option>

                    <option value="Guatemala " id="502">Guatemala </option>

                    <option value="Guinea " id="224">Guinea </option>

                    <option value="Guinea - Bissau " id="245">Guinea - Bissau </option>

                    <option value="Guyana " id="592">Guyana </option>

                    <option value="Haiti " id="509">Haiti </option>

                    <option value="Honduras " id="504">Honduras </option>

                    <option value="Hong Kong " id="852">Hong Kong </option>

                    <option value="Hungary " id="36">Hungary </option>

                    <option value="Iceland " id="354">Iceland </option>

                    <option value="India " id="91">India </option>

                    <option value="Indonesia " id="62">Indonesia </option>

                    <option value="Iran " id="98">Iran </option>

                    <option value="Iraq " id="964">Iraq </option>

                    <option value="Israel " id="972">Israel </option>

                    <option value="Italy " id="39">Italy </option>

                    <option value="Ivory Coast " id="225">Ivory Coast </option>

                    <option value="Jamaica " id="1876">Jamaica </option>

                    <option value="Japan " id="81">Japan </option>

                    <option value="Jordan " id="962">Jordan </option>

                    <option value="Kazakhstan " id="8">Kazakhstan </option>

                    <option value="Kenya " id="254">Kenya </option>

                    <option value="Kiribati " id="686">Kiribati </option>

                    <option value="Korea North " id="850">Korea North </option>

                    <option value="Korea South " id="82">Korea South </option>

                    <option value="Kuwait " id="965">Kuwait </option>

                    <option value="Kyrgyzstan " id="996">Kyrgyzstan </option>

                    <option value="Laos " id="856">Laos </option>

                    <option value="Latvia " id="371">Latvia </option>

                    <option value="Lebanon " id="961">Lebanon </option>

                    <option value="Lesotho " id="266">Lesotho </option>

                    <option value="Liberia " id="231">Liberia </option>

                    <option value="Libya " id="218">Libya </option>

                    <option value="Liechtenstein " id="417">Liechtenstein </option>

                    <option value="Lithuania " id="370">Lithuania </option>

                    <option value="Luxembourg " id="352">Luxembourg </option>

                    <option value="Macao " id="853">Macao </option>

                    <option value="Macedonia " id="389">Macedonia </option>

                    <option value="Madagascar " id="261">Madagascar </option>

                    <option value="Malawi " id="265">Malawi </option>

                    <option value="Malaysia " id="60">Malaysia </option>

                    <option value="Maldives " id="960">Maldives </option>

                    <option value="Mali " id="223">Mali </option>

                    <option value="Malta " id="356">Malta </option>

                    <option value="Marshall Islands " id="692">Marshall Islands </option>

                    <option value="Martinique " id="596">Martinique </option>

                    <option value="Mauritania " id="222">Mauritania </option>

                    <option value="Mayotte " id="269">Mayotte </option>

                    <option value="Mexico " id="52">Mexico </option>

                    <option value="Micronesia " id="691">Micronesia </option>

                    <option value="Moldova " id="373">Moldova </option>

                    <option value="Monaco " id="377">Monaco </option>

                    <option value="Mongolia " id="976">Mongolia </option>

                    <option value="Montserrat " id="1664">Montserrat </option>

                    <option value="Morocco " id="212">Morocco </option>

                    <option value="Mozambique " id="258">Mozambique </option>

                    <option value="Myanmar " id="95">Myanmar </option>

                    <option value="Namibia " id="264">Namibia </option>

                    <option value="Nauru " id="674">Nauru </option>

                    <option value="Nepal " id="977">Nepal </option>

                    <option value="Netherlands " id="31">Netherlands </option>

                    <option value="New Caledonia " id="687">New Caledonia </option>

                    <option value="New Zealand " id="64">New Zealand </option>

                    <option value="Nicaragua " id="505">Nicaragua </option>

                    <option value="Niger " id="227">Niger </option>

                    <option value="Nigeria " id="234">Nigeria </option>

                    <option value="Niue " id="683">Niue </option>

                    <option value="Norfolk Islands " id="672">Norfolk Islands </option>

                    <option value="Northern Marianas " id="670">Northern Marianas </option>

                    <option value="Norway " id="47">Norway </option>

                    <option value="Oman " id="968">Oman </option>

                    <option value="Palau " id="680">Palau </option>

                    <option value="Panama " id="507">Panama </option>

                    <option value="Papua New Guinea " id="675">Papua New Guinea </option>

                    <option value="Paraguay " id="595">Paraguay </option>

                    <option value="Peru " id="51">Peru </option>

                    <option value="Philippines " id="63">Philippines </option>

                    <option value="Poland " id="48">Poland </option>

                    <option value="Portugal " id="351">Portugal </option>

                    <option value="Puerto Rico " id="1787">Puerto Rico </option>

                    <option value="Qatar " id="974">Qatar </option>

                    <option value="Reunion " id="262">Reunion </option>

                    <option value="Romania " id="40">Romania </option>

                    <option value="Russia " id="9">Russia </option>

                    <option value="Rwanda " id="250">Rwanda </option>

                    <option value="San Marino " id="378">San Marino </option>

                    <option value="Sao Tome &amp; Principe " id="239">Sao Tome &amp; Principe </option>

                    <option value="Saudi Arabia " id="966">Saudi Arabia </option>

                    <option value="Senegal " id="221">Senegal </option>

                    <option value="Serbia " id="382">Serbia </option>

                    <option value="Seychelles " id="248">Seychelles </option>

                    <option value="Sierra Leone " id="232">Sierra Leone </option>

                    <option value="Singapore " id="65">Singapore </option>

                    <option value="Slovak Republic " id="421">Slovak Republic </option>

                    <option value="Slovenia " id="386">Slovenia </option>

                    <option value="Solomon Islands " id="677">Solomon Islands </option>

                    <option value="Somalia " id="252">Somalia </option>

                    <option value="South Africa " id="27">South Africa </option>

                    <option value="Spain " id="34">Spain </option>

                    <option value="Sri Lanka " id="94">Sri Lanka </option>

                    <option value="St. Helena " id="290">St. Helena </option>

                    <option value="St. Kitts " id="1869">St. Kitts </option>

                    <option value="St. Lucia " id="1758">St. Lucia </option>

                    <option value="Sudan " id="249">Sudan </option>

                    <option value="Suriname " id="597">Suriname </option>

                    <option value="Swaziland " id="268">Swaziland </option>

                    <option value="Sweden " id="46">Sweden </option>

                    <option value="Switzerland " id="41">Switzerland </option>

                    <option value="Syria " id="963">Syria </option>

                    <option value="Taiwan " id="886">Taiwan </option>

                    <option value="Tajikstan " id="10">Tajikstan </option>

                    <option value="Thailand " id="66">Thailand </option>

                    <option value="Togo " id="228">Togo </option>

                    <option value="Tonga " id="676">Tonga </option>

                    <option value="Trinidad &amp; Tobago " id="1868">Trinidad &amp; Tobago </option>

                    <option value="Tunisia " id="216">Tunisia </option>

                    <option value="Turkey " id="90">Turkey </option>

                    <option value="Turkmenistan " id="7">Turkmenistan </option>

                    <option value="Turkmenistan " id="993">Turkmenistan </option>

                    <option value="Turks &amp; Caicos Islands " id="1649">Turks &amp; Caicos Islands </option>

                    <option value="Tuvalu " id="688">Tuvalu </option>

                    <option value="Uganda " id="256">Uganda </option>

                    <option value="UK " id="44">UK </option>

                    <option value="Ukraine " id="380">Ukraine </option>

                    <option value="United Arab Emirates " id="971">United Arab Emirates </option>

                    <option value="Uruguay " id="598">Uruguay </option>

                    <option value="United States " id="2" selected="">United States</option>

                    <option value="Uzbekistan " id="12">Uzbekistan </option>

                    <option value="Vanuatu " id="678">Vanuatu </option>

                    <option value="Vatican City " id="379">Vatican City </option>

                    <option value="Venezuela " id="58">Venezuela </option>

                    <option value="Vietnam " id="84">Vietnam </option>

                    <option value="Virgin Islands - British " id="85">Virgin Islands - British </option>

                    <option value="Virgin Islands - US " id="86">Virgin Islands - US </option>

                    <option value="Wallis &amp; Futuna " id="681">Wallis &amp; Futuna </option>

                    <option value="Yemen North" id="969">Yemen North</option>

                    <option value="Yemen South" id="967">Yemen South</option>

                    <option value="Yugoslavia " id="381">Yugoslavia </option>

                    <option value="Zaire " id="243">Zaire </option>

                    <option value="Zambia " id="260">Zambia </option>

                    <option value="Zimbabwe " id="263">Zimbabwe </option>

                  </select>
                                                </div>
                                            </div>
                                        </div>
                                    <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Phone No. <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                    
                                                    <input type="text" class="form-control pl-2" name="countrycode" id="countrycode" value="1" style="width:23%;" readonly>
                                                   <input type="text" class="form-control pl-2" placeholder="Phone No." name="phoneno" id="phoneno" style="width: 78%" onkeypress="return isNumber(event);" minlength="10" maxlength="10">
                                            <span id="phonenoerror"></span> 
                                                </div>
                                            </div>
                                        </div>
										
										<div class="col-md-12">
                                            <div class="mb-3">
                                                <label class="form-label"> Message <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                   <textarea  rows="2" class="form-control pl-2" placeholder="Enter Message" name="msg" id="msg"></textarea>
                                        <span id="msgErr" class="error"></span>           
                                                </div>
                                            </div>
                                        </div>
                                        
                                        	<div class="col-md-8">
                                            <div class="mb-3">
                                                <label class="form-label"> Captcha <span class="text-danger">*</span></label>
                                                <div class="form-icon position-relative">
                                                  <input name="c_captcha1" type="text" id="c_captcha1" class="form-control pl-2" placeholder="Enter Code as Seen">
                                	<span class="captcha" style="background-color: #4A6983;color:#FFF;padding: 8px 12px;padding-right: 15px;margin-top: -39px;float: right;margin-right: 0px;border-radius: 5px;"><?php echo $captchacode1 = rand(1111,9999);?></span>
	                                <input type="hidden" id="ccode1" value="<?php echo $captchacode1;?>" />
                                	<span id="cmntcaptcha1" class="error"></span>           
                                                </div>
                                            </div>
                                        </div>
										
										<div class="col-md-4 mt-4">
										   
										    <button type="submit" name="submit" id="btnsub" class="col-sm-12 btn btn-warning m-1">Submit</button>
										    </div>
                                 
                                    </div>
                                </form>
                            </div>
                        </div>
					
                        <div class="shape-before">
                            <!--<div class="carousel-cell"><img src="images/right-img.jpg" class="img-fluid rounded-md" alt=""></div>-->
                            <img src="images/shapes/shape1.png" class="img-fluid shape-img" alt="">
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->
        </section><!--end section-->
        <div class="position-relative">
            <div class="shape overflow-hidden text-white">
                <svg viewBox="0 0 2880 250" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M720 125L2160 0H2880V250H0V125H720Z" fill="currentColor"></path>
                </svg>
            </div>
        </div>
        <!-- Hero End -->

        <!-- Start -->
      <section class="section">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5 col-md-6">
                        <img src="images/learning-image.png" class="img-fluid" alt="">
                    </div><!--end col-->

                    <div class="col-lg-6 col-md-6 mt-4 pt-2 mt-sm-0 pt-sm-0">
                        <div class="section-title text-md-start text-center">
                            <h4 class="title mb-4">Flexible Learning

<br> From Anywhere, At Anytime</h4>
                            <p class="mb-0 para-desc">Learninginloo stands up to the name and makes it easier for you to come across lessons which are planned in a way that they can be learned easily even in the loo because these courses are:</p>
                            
                         <ul class="list-unstyled mt-4">
                        <li class="mb-0"><span class="text-primary h5 me-2"><i class="fa fa-check-circle"></i> </span>Easy to Understand </li>
                        <li class="mb-0"><span class="text-primary h5 me-2"><i class="fa fa-check-circle"></i> </span>Compact and Precise
</li>
                        <li class="mb-0"><span class="text-primary h5 me-2"><i class="fa fa-check-circle"></i> </span>Short Modules to Save Time </li>
                     <li class="mb-0"><span class="text-primary h5 me-2"><i class="fa fa-check-circle"></i> </span>Well-explained Concepts </li>
                        <li class="mb-0"><span class="text-primary h5 me-2"><i class="fa fa-check-circle"></i> </span>Fitting to All</li>
					 </ul>
                        </div>
                    </div><!--end col-->
                </div><!--end row-->
            </div><!--end container-->

          

         
        </section>
		
		<section class="technology">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 mx-auto text-center mb-5">
                <h2>WHAT ALL IS INCLUDED IN THE SERVICES?</h2>
                <p>We provide easy to learn courses through an e-learning service that enhances the skills and knowledge for the betterment of your business or corporation. Below are some of the thing you and your staff can learn with LearningInLoo
</p>
            </div>
            <div class="col-12 digital-technolist mt-0">
<ul>
<li><i class="fa fa-file-text" aria-hidden="true"></i><br>Content Development
</li>
<li><i class="fa fa-lightbulb-o" aria-hidden="true"></i><br>Employee Training Ideas
</li>
<li><i class="fa fa-users" aria-hidden="true"></i><br>Staff and Talent Management
</li>
<li><i class="fa fa-bar-chart" aria-hidden="true"></i><br>Strategy Planning</li>
<li><i class="fa fa-line-chart" aria-hidden="true"></i><br>Skills Development
</li>
</ul>
</div>
        </div>
    </div>
</section>
		
<section class="why-us">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 text-center mb-5">
                <h2>The Simple Process of Starting </h2>
            </div>
            <div class="col-sm-4">
                <div class="why-us-in">
                    <div class="icon">
                    <h4>1.</h4>
                    </div>
                    <div class="content">
                    <h3>Sign Up</h3>
                    <p>The first step, as in any other process, is to sign-up with your ID.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-sm-4">
                <div class="why-us-in">
                    <div class="icon">
                    <h4>2.</h4>
                    </div>
                    <div class="content">
                    <h3>Choose A Course</h3>
                    <p>Then choose the course you want to yourself or your staff to pursue and make the payment for the same.</p>
                    </div>
                </div>
            </div>
            
            <div class="col-sm-4">
                <div class="why-us-in">
                    <div class="icon">
                    <h4>3.</h4>
                    </div>
                    <div class="content">
                    <h3>Start Learning</h3>
                    <p>Once you have successfully signed-up and bought the course, start learning from anywhere, anytime.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
           
        <footer class="footer footer-bar">
            <div class="container text-center">
                <div class="row align-items-center">
                    <div class="col-sm-12 text-center">
                        <div class="text-sm-center">
                            <p class="mb-0">© 2021-2022 Learning Inloo. All Rights Reserved</p>
                        </div>
                    </div><!--end col-->

     
                </div><!--end row-->
            </div><!--end container-->
        </footer><!--end footer-->
        <!-- Footer End -->


        <!-- javascript -->
        <script src="js/bootstrap.bundle.min.js" async></script>
        <!-- Main Js -->
        <script src="js/plugins.init.js" async></script>
        <script src="js/app.js" async></script>
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js" async></script>
      <script>
    function getcountrycode()
	 {
		$("#country_code").val($("select[name='country'] option:selected").attr('name')); 
	 }
    </script>
     <script>
    function getcountrycode1()
	 {
		$("#countrycode").val($("select[name='countryname'] option:selected").attr('name')); 
	 }
    </script>
     <script>
    function validatecontactus(){
        
     
    var error = "";
	var email_pattern_match = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var regurl = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;	
	var phone_pattern_match = /^[0-9]+$/;
	

    
	var thisvalue = $('#name').val();
	
	if (thisvalue == "") {
		$('#name').css("border-color","red");
		$('#nameErr').html('Enter Name');
		error = 1;
	}
	

	
	var thisvalue = $('#email').val();
	if (thisvalue == "") {
		$('#email').css("border-color","red");
		$('#emailErr').html('Enter Email Id');
		error = 1;
	}
	if (!email_pattern_match.test($('#email').val()) && thisvalue!="") {
		$('#email').css("border-color","red");
		$('#emailErr').html('Invalid Email Format');
		error = 1;
	}
	var thisvalue = $('#phone').val();
	if (thisvalue == "") {
		$('#phone').css("border-color","red");
		$('#phoneErr').html(' Enter Phone No.');
		error = 1;
	}
	
	var thisvalue = $('#phone').val();
	if (!phone_pattern_match.test($('#phone').val()) && thisvalue !="") {
		$('#phone').css("border-color","red");
		$('#phoneErr').html('Invalid Phone');
		error = 1;
	}
	

var message = $('#message').val();
      if (message == "") {
      $('#message').css("border-color","red");
      $('#messageErr').html('Enter Message');
      error = 1;
    }
    if(regurl.test($("#message").val()))
  {
      $('#message').css("border-color","red");
    $('#messageErr').html('URL links are not allowed, please remove URL link from the message');
    error = 1;
  }
		
      
	var thisvalue = $('#c_captcha').val();
	if (thisvalue == "") {
		$('#c_captcha').css("border-color","red");
		$('#cmntcaptcha').html('You can\'t leave Captcha Code');
		error = 1;
	}
	
	if($("#c_captcha").val()!=$("#ccode").val() && $('#c_captcha').val() != "")
	{
	  $('#c_captcha').css("border-color","red");
	  $('#cmntcaptcha').html('Invalid captcha code!');
	  	error = 1;
	 // return false;
	}
	
    
	if(error!=1)
	{
		
		$('#cmntcaptcha').html('');
		
	$.ajax({
		type: "POST",
		url: 'contactusformprocess.php',
		data: $('#myForm').serialize(),
		beforeSend: function() {
			// setting a timeout
		
			$('#msgloader12').html('<div class="alert alert-primary">Please Wait!</div>');
			$('#sbmtbtn').attr('disabled',true);
			
		},
		success: function(result){
			//return false;
			if(result=='fail' && result!="")
			{
			$('#msgloader12').html('<div class="alert alert-danger">Something Went Wrong Please Try Again Later!</div>');
				
				$('#sbmtbtn').removeAttr('disabled');
				
				
			}
			else
			{
			    $('#myForm')[0].reset();

			    $('#sbmtbtn').removeAttr('disabled');
				$('input:text').val('');
				
				$('textarea').val('');
				$('select').val('');
				
				$('#msgloader12').html('<div class="alert alert-success">Message Sent Successfully!</div>');
			}
			setTimeout(function(){ $('#msgloader12').html(''); }, 5000);
		},
	});
	}
	return false;
    }
</script>
 <script>
    function validateform(){
        
     //alert('hi');
    var error = "";
	var email_pattern_match = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var regurl = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;	
	var phone_pattern_match = /^[0-9]+$/;
	

    
	var thisvalue = $('#fname').val();
	
	if (thisvalue == "") {
		$('#fname').css("border-color","red");
		$('#fnameErr').html('Enter Name');
		error = 1;
	}
	

	
	var thisvalue = $('#emailid').val();
	if (thisvalue == "") {
		$('#emailid').css("border-color","red");
		$('#emailidErr').html('Enter Email Id');
		error = 1;
	}
	if (!email_pattern_match.test($('#emailid').val()) && thisvalue!="") {
		$('#emailid').css("border-color","red");
		$('#emailidErr').html('Invalid Email Format');
		error = 1;
	}
	var thisvalue = $('#phoneno').val();
	if (thisvalue == "") {
		$('#phoneno').css("border-color","red");
		$('#phonenoErr').html(' Enter Phone No.');
		error = 1;
	}
	
	var thisvalue = $('#phoneno').val();
	if (!phone_pattern_match.test($('#phoneno').val()) && thisvalue !="") {
		$('#phoneno').css("border-color","red");
		$('#phonenoErr').html('Invalid Phone');
		error = 1;
	}
	

var msg = $('#msg').val();
      if (msg == "") {
      $('#msg').css("border-color","red");
      $('#msgErr').html('Enter Message');
      error = 1;
    }
    if(regurl.test($("#msg").val()))
  {
      $('#msg').css("border-color","red");
    $('#msgErr').html('URL links are not allowed, please remove URL link from the message');
    error = 1;
  }
		
      
	var thisvalue = $('#c_captcha1').val();
	if (thisvalue == "") {
		$('#c_captcha1').css("border-color","red");
		$('#cmntcaptcha1').html('You can\'t leave Captcha Code');
		error = 1;
	}
	
	if($("#c_captcha1").val()!=$("#ccode1").val() && $('#c_captcha1').val() != "")
	{
	  $('#c_captcha1').css("border-color","red");
	  $('#cmntcaptcha1').html('Invalid captcha code!');
	  	error = 1;
	 // return false;
	}
	//alert(error);
    
	if(error!=1)
	{
		
		$('#cmntcaptcha1').html('');
		
	$.ajax({
		type: "POST",
		url: 'contactusprocess.php',
		data: $('#contactus').serialize(),
		beforeSend: function() {
			// setting a timeout
		
			$('#msgloader1').html('<div class="alert alert-primary">Please Wait!</div>');
			$('#btnsub').attr('disabled',true);
			
		},
		success: function(results){
		
			if(results=='fail' && results!="")
			{
			$('#msgloader1').html('<div class="alert alert-danger">Something Went Wrong Please Try Again Later!</div>');
				
				$('#btnsub').removeAttr('disabled');
				
				
			}
			else
			{
			    $('#contactus')[0].reset();

			    $('#btnsub').removeAttr('disabled');
				$('input:text').val('');
				
				$('textarea').val('');
				$('select').val('');
				
				$('#msgloader1').html('<div class="alert alert-success">Message Sent Successfully!</div>');
			}
			setTimeout(function(){ $('#msgloader1').html(''); }, 5000);
		},
	});
	}
	return false;
    }
</script>
<script>
$("input").focus(function(){
	 var id=this.id;
	 $("#"+id+"Err").html('');
	 $("#"+id).css('border','1px solid #ccc');
});
$("select").focus(function(){
	 var id=this.id;
	 $("#"+id+"Err").html('');
	 $("#"+id).css('border','1px solid #ccc');
});
$("textarea").focus(function(){
	 var id=this.id;
	 $("#"+id+"Err").html('');
	 $("#"+id).css('border','1px solid #ccc');
});
</script>
<script>

function ValidateAlpha(evt)
    {
        var keyCode = (evt.which) ? evt.which : evt.keyCode
        if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32)
         
        return false;
            return true;
    }


</script>

<script>
$('#email').change(function(e) {
	 var name= $('#name').val();
	
	 
	 if($('#name').val()!="" && $('#name').val()!=null)
	 {
		var name= $('#name').val();
	 }
	 var phone= $('#phone').val();
		 if($('#phone').val()!="" && $('#phone').val()!=null)
	 {
		var phone= $('#phone').val();
	 }
	 
	var email= $(this).val();
	if(email!='')
	{
		$.ajax({
			type: "POST",
			url: "click_enquiry.php",
			data: { name: name,email: email,phone: phone},
			success: function(data) {
				//alert(data);
				}

		});
	}
});    
</script>
<script>
$('#phone').change(function(e) {
	 var name= $('#name').val();
	
	 
	 if($('#name').val()!="" && $('#name').val()!=null)
	 {
		var name= $('#name').val();
	 }
	 var email= $('#email').val();
		 if($('#email').val()!="" && $('#email').val()!=null)
	 {
		var email= $('#email').val();
	 }
	 
	var phone= $(this).val();
	if(phone!='')
	{
		$.ajax({
			type: "POST",
			url: "click_enquiry.php",
			data: { name: name,email: email,phone: phone},
			success: function(data) {
				//alert(data);
				}

		});
	}
});    
</script>
<script>
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
<script>
$('#emailid').change(function(e) {
	 var name= $('#fname').val();
	
	 
	 if($('#fname').val()!="" && $('#fname').val()!=null)
	 {
		var name= $('#fname').val();
	 }
	 var phone= $('#phoneno').val();
		 if($('#phoneno').val()!="" && $('#phoneno').val()!=null)
	 {
		var phone= $('#phoneno').val();
	 }
	 
	var email= $(this).val();
	if(email!='')
	{
		$.ajax({
			type: "POST",
			url: "click_enquiry.php",
			data: { name: name,email: email,phone: phone},
			success: function(data) {
				//alert(data);
				}

		});
	}
});    
</script>
<script>
$('#phoneno').change(function(e) {
	 var name= $('#fname').val();
	
	 
	 if($('#fname').val()!="" && $('#fname').val()!=null)
	 {
		var name= $('#fname').val();
	 }
	 var email= $('#emailid').val();
		 if($('#emailid').val()!="" && $('#emailid').val()!=null)
	 {
		var email= $('#emailid').val();
	 }
	 
	var phone= $(this).val();
	if(phone!='')
	{
		$.ajax({
			type: "POST",
			url: "click_enquiry.php",
			data: { name: name,email: email,phone: phone},
			success: function(data) {
				//alert(data);
				}

		});
	}
});    
</script>
    </body>

</html>