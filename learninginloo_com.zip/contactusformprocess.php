<?php
require_once('Mandrill_Api/src/Mandrill.php');
$mandrill = new Mandrill('bJ0APu1q1CMbGD2ysPBrmg');
		
if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
	$ip = $_SERVER['HTTP_CLIENT_IP'];
} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
} else {
	$ip = $_SERVER['REMOTE_ADDR'];
}

$start_time=$_POST['start_time'];

$end_time=time();
 $diff = abs($end_time - $_POST['start_time']); 
 

 //echo "<br>";
  $seconds = floor(($diff - $years * 365*60*60*24 - $months*30*60*60*24 - $days*60*60*24 - $hours*60*60 - $minutes*60)); 

if($_POST['start_time']=="" or $seconds < 10)
{
  echo '<script>alert("You are bot. Not allowed.");window.history.go(-1);</script>'; return;
}
if($_POST['email']!="" && $_POST['checkval']=="")
{

	$Datas['name'] = ucfirst($_POST['name']);
	$Datas['email_id'] = $_POST['email'];
    $Datas['phone'] = $_POST['phone'];
    $Datas['country'] = $_POST['country'];
    $Datas['country_code'] = $_POST['country_code'];
	$Datas['message'] = $_POST['message'];	
	
	$Datas['IP_Address'] = $_SERVER['REMOTE_ADDR'];
	$Datas['Page_Referer'] = $_SERVER['HTTP_REFERER'];

	$body='Dear '.$Datas['name'].'<br/><br/>Your submitted details are as follows:<br/><br/>';
	$body.='<strong>Name: </strong>'. $Datas['name'].'<br/>';
	$body.='<strong>Email: </strong>'.$Datas['email_id'].'<br/>';
	$body.='<strong>Country: </strong>'.$Datas['country'].'<br/>';
	$body.='<strong>Phone: </strong>'.$Datas['country_code'].''.$Datas['phone'].'<br/>';
	 if($Datas['message']!="")
	{	
		$body.='<strong>Message : </strong>'.$Datas['message'].'<br/>';
	}
	$body.='<strong>Refferal Link: </strong>'.$_SERVER["HTTP_REFERER"].'<br/>';                           

	$body.='<br/> Thanks & regards, <br/>learninginloo.com<br/>';
	
	$subject = "Contact Us Form";
	

	$message = array(
	'html' => $body,
	'subject' => $subject.' || learninginloo.com',
	'from_email' => 'info@learninginloo.com',
	'from_name' => 'learninginloo.com',
	'to' => array(
		array(
			'email' => $Datas['email_id'],
			'name' => $Datas['name'],
			'type' => 'to'
		),
		array(
			'email' => "pnt.chd@gmail.com", 
			'name' => 'Admin',
			'type' => 'bcc'
		)
	)
	);
	$async = false;
	$ip_pool = '';


	$result = $mandrill->messages->send($message, $async, $ip_pool); 

	if($result) 
	{
		echo 'success';
	}
	else
	{
		echo 'fail';
	}

}

?>